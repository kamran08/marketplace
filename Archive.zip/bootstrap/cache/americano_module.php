<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Americano\\Providers\\AmericanoServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Americano\\Providers\\AmericanoServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);