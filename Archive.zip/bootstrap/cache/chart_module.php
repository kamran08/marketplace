<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Chart\\Providers\\ChartServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Chart\\Providers\\ChartServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);