<h3>Email verification</h3>

<p>Please click this link to verify your email</p>
<p>
<a href="http://bookingmarket.localhost/activationlink?token={{$data['activation_token']}}">Click here </a>

</p>