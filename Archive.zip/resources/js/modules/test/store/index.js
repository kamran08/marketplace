export default {
   
    state: {
        testModuleNumber: 34344
    },
    getters: {},
    mutations: {},
    actions: {}
  }