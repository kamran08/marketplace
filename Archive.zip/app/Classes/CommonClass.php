<?php
namespace App\Classes;

class CommonClass {
    public function testing(){
        \Log::info('Testing is correct');
    }
}

