<template>
    <div>
        <div class="container">
            <div class="_box_shadow2 terms ">
                <p class="_title3">Terms</p>

                <p>Link3 Technologies Ltd. is a full-service IT Solution Provider that has been operating in Bangladesh market for over 18 years with a very high level of success, achieved through an uncompromised service quality and customer satisfaction. Link3's highly trained professionals can ensure a standard of 
                    service that remains unmatched by any other player in the market.</p>

                <ul>
                    <li>Link3 Technologies Ltd. is a full-service IT Solution Provider that has been operating in Bangladesh market for over 18 years with a very high level of success, achieved through an uncompromised service quality and customer satisfaction. Link3's highly trained professionals can ensure a standard of service that remains unmatched by any other player in the market.</li>
                    <li>Link3 Technologies Ltd. is a full-service IT Solution Provider that has been operating in Bangladesh market for over 18 years with a very high level of success, achieved through an uncompromised service quality and customer satisfaction. Link3's highly trained professionals can ensure a standard of service that remains unmatched by any other player in the market.</li>
                    <li>Link3 Technologies Ltd. is a full-service IT Solution Provider that has been operating in Bangladesh market for over 18 years with a very high level of success, achieved through an uncompromised service quality and customer satisfaction. Link3's highly trained professionals can ensure a standard of service that remains unmatched by any other player in the market.</li>
                    <li>Link3 Technologies Ltd. is a full-service IT Solution Provider that has been operating in Bangladesh market for over 18 years with a very high level of success, achieved through an uncompromised service quality and customer satisfaction. Link3's highly trained professionals can ensure a standard of service that remains unmatched by any other player in the market.</li>
                </ul>
            </div>
        </div>
    </div>
</template>
