<template>
  <div>
          <div class="order_main">
            <div class="container">
                <div class="_title_header _b_color2">
                    <h3 class="_title">Your Order</h3>
                </div>

                <div class="row">
                        <!-- Left Card -->
                    <div class="col-12 col-md-3 col-lg-3">
                        <h4 class="_title4">JOB</h4>

                        <div class="order_left_card">
                                <!-- card -->
                            <div class="_1job_card">
                                <div class="_1job_card_rating">
                                    <ul class="_1job_card_rating_ul">
                                        <li class="_color"><i class="fas fa-star"></i></li>
                                        <li class="_color"><i class="fas fa-star"></i></li>
                                        <li class="_color"><i class="fas fa-star"></i></li>
                                        <li class=""><i class="fas fa-star"></i></li>
                                        <li class=""><i class="fas fa-star"></i></li>
                                        <li class="_1job_card_rating_num">(2k+)</li>
                                    </ul>
                                </div>

                                <div class="_1job_card_img">
                                    <img class="_1job_card_img_pic" src="img/V90.jpg" alt="" title="">
                                </div>

                                <div class="_1job_card_status">
                                    <p class="_1job_card_status_text _text_overflow2">por incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                                    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat n</p>
                                </div>

                                <div class="_1job_card_bottom">
                                    <p class="_1job_card_by"><span class="_1job_card_by_span">by</span> Luca Tony</p>

                                    <div class="_1job_card_dollar">
                                        <p class="_1job_card_dollar_text _color"> 25</p>
                                        <p class="_1job_card_dollar_sine _color">$</p>
                                    </div>
                                </div>
                            </div>
                                <!-- card -->
                        </div>
                    </div>
                        <!-- Left Card -->

                        <!-- Right Description -->
                    <div class="col-12 col-md-9 col-lg-9 order_right">
                        <div class="order_description _dis_flex _b_color2">
                            <div class="order_description_status">
                                <h4 class="_title4">DESCRIPTION</h4>

                                <p class="_text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse</p>
                            </div>

                            <div class="order_description_price _text_right">
                                <h4 class="_title4">PRICE</h4>

                                <div class="Details_pro_extra_do _dis_iblock">
                                    <p class="Details_pro_extra_do_text  _color"> 25</p>
                                    <p class="Details_pro_extra_ds _color">$</p>
                                </div>
                            </div>
                        </div>

                        <div class="order_extra">
                            <h4 class="_title4">EXTRA</h4>

                            <div class="Details_pro_extra_all">
                                    <!-- items -->
                                <div class="Details_pro_extra_main _b_color2 _dis_flex">
                                    <div class="Details_pro_extra_redio">
                                        <p>
                                            <input type="radio" id="test1" name="radio-group" checked="">
                                            <label for="test1"></label>
                                        </p>
                                    </div>

                                    <div class="Details_pro_extra_status">
                                        <p class="Details_pro_extra_status_text">
                                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                                        </p>
                                    </div>

                                    <div class="Details_pro_extra_do">
                                        <p class="Details_pro_extra_do_text  _color"> 25</p>
                                        <p class="Details_pro_extra_ds _color">$</p>
                                    </div>
                                </div>
                                     <!-- items -->

                                     <!-- items -->
                                <div class="Details_pro_extra_main _b_color2 _dis_flex">
                                    <div class="Details_pro_extra_redio">
                                        <p>
                                            <input type="radio" id="test1" name="radio-group" checked="">
                                            <label for="test3"></label>
                                        </p>
                                    </div>

                                    <div class="Details_pro_extra_status">
                                        <p class="Details_pro_extra_status_text">
                                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                                        </p>
                                    </div>

                                    <div class="Details_pro_extra_do">
                                        <p class="Details_pro_extra_do_text  _color"> 25</p>
                                        <p class="Details_pro_extra_ds _color">$</p>
                                    </div>
                                </div>
                                     <!-- items -->

                                     <!-- items -->
                                <div class="Details_pro_extra_main _b_color2 _dis_flex">
                                    <div class="Details_pro_extra_redio">
                                        <p>
                                            <input type="radio" id="test1" name="radio-group" checked="">
                                            <label for="test2"></label>
                                        </p>
                                    </div>

                                    <div class="Details_pro_extra_status">
                                        <p class="Details_pro_extra_status_text">
                                            tempor incididunt ut labore et .
                                        </p>
                                    </div>

                                    <div class="Details_pro_extra_do">
                                        <p class="Details_pro_extra_do_text  _color"> 25</p>
                                        <p class="Details_pro_extra_ds _color">$</p>
                                    </div>
                                </div>
                                     <!-- items -->
                            </div>


                            <div class="order_total _b_color2">
                                <div class="order_total_num _dis_flex">
                                    <h4 class="_title4">TOTAL</h4>

                                    <div class="_1job_card_dollar">
                                        <p class="_1job_card_dollar_text _color"> 25</p>
                                        <p class="_1job_card_dollar_sine _color">$</p>
                                    </div>
                                </div>

                                <div class="order_total_button _text_right">
                                    <button class="_bg _btn _block_buttons_btn" type="button"> CHECK OUT NOW </button>
                                </div>
                            </div>
                        </div>
                    </div>
                        <!-- Right Description -->
                </div>
            </div>
        </div>
            <!--==========================
                        Order
            ===========================-->






</div style="height:100px;">

</template>

<script>
export default {

}
</script>

<style>

</style>
