<?php

return [
    'name' => 'Chart'
];
