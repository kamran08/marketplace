<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MS4 London</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel=" stylesheet" href="<?php echo e(asset('css/grid.min.css')); ?>">
    <link rel=" apple-touch-icon" href="<?php echo e(asset('apple-touch-icon.png')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('https://use.fontawesome.com/releases/v5.7.2/css/all.css')); ?>" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <!--  -->

<body>
    <div id="app">
        <mainapp></mainapp>
    </div>
    <script>
        (function() {
            window.Laravel = {
                csrfToken: '<?php echo e(csrf_token()); ?>'
            };
            <?php if(Auth::check()): ?>
            window.authUser = <?php echo Auth::user(); ?>

            <?php else: ?>
            window.authUser = false
            <?php endif; ?>
        })();
    </script>
</body>

<script src="/js/app.js"></script>
<script src="//unpkg.com/vue-plain-pagination@0.2.1"></script>

</html>